var websocket;
var kefu_id_;

var account_;

//定时器
var clock_int;

//对话操作
var doc = document;
$(function () {
    var dialogueInput = doc.getElementById('dialogue_input'),
        dialogueContain = doc.getElementById('dialogue_contain'),
        dialogueHint = doc.getElementById('dialogue_hint'),
        btnOpen_1 = doc.getElementById('btn_open_1'),
        btnOpen_2 = doc.getElementById('btn_open_2'),
        btnOpen_3 = doc.getElementById('btn_open_3'),
        btnOpen_4 = doc.getElementById('btn_open_4'),
        btnOpen_5 = doc.getElementById('btn_open_5'),
        btnClose = doc.getElementById('btn_close'),
        btnopen_ly = doc.getElementById('btn_open_ly'),
        btnopen_ly_close = doc.getElementById('pop_ly_id_div_close'),
        timer,
        timerId,
        shiftKeyOn = false;  // 辅助判断shift键是否按住


    function recv_data(content) {
        var nodeP = doc.createElement('p'),
            nodeSpan = doc.createElement('span');
        nodeP.classList.add('dialogue-service-contain');
        nodeSpan.classList.add('dialogue-text', 'dialogue-service-text');
        nodeSpan.innerHTML = content;
        nodeP.appendChild(nodeSpan);
        dialogueContain.appendChild(nodeP);
        dialogueContain.scrollTop = dialogueContain.scrollHeight;
    }

    function error_handle(errorid) {
        switch (errorid) {
            case  -1:
                // {"resultCode":-1,"resultMsg":"leave","protocol":3,"data":[]}

                var nodeP = doc.createElement('p'),
                    nodeSpan = doc.createElement('span');
                nodeP.classList.add('dialogue-service-contain');
                nodeSpan.classList.add('dialogue-text', 'dialogue-service-text');
                nodeSpan.innerHTML = "客服未在线";
                nodeP.appendChild(nodeSpan);
                dialogueContain.appendChild(nodeP);
                dialogueContain.scrollTop = dialogueContain.scrollHeight;

                break;
            case -2:
                var nodeP = doc.createElement('p'),
                    nodeSpan = doc.createElement('span');
                nodeP.classList.add('dialogue-service-contain');
                nodeSpan.classList.add('dialogue-text', 'dialogue-service-text');
                nodeSpan.innerHTML = "客服已离线,稍后再试";

                nodeP.appendChild(nodeSpan);
                dialogueContain.appendChild(nodeP);
                dialogueContain.scrollTop = dialogueContain.scrollHeight;
                kefu_id_ = "";
                break;
        }
    }

    // $("#pop_ly_id_div").click(function () {$("#pop_ly_id_div").hide();}

    $("#btn_send").click(function () {

        if (submitText(dialogueInput.value) == true) {
            var nodeP = doc.createElement('p'),
                nodeSpan = doc.createElement('span');
            nodeP.classList.add('dialogue-customer-contain');
            nodeSpan.classList.add('dialogue-text', 'dialogue-customer-text');
            nodeSpan.innerHTML = dialogueInput.value;
            nodeP.appendChild(nodeSpan);
            dialogueContain.appendChild(nodeP);
            dialogueContain.scrollTop = dialogueContain.scrollHeight;
            dialogueInput.value = null;
        }

    });

    function open_chat_windows() {
        $('.dialogue-support-btn').css({'display': 'none'});
        $('.dialogue-main').css({'display': 'inline-block', 'height': '0'});
        $('.dialogue-main').animate({'height': '600px'})


        $('.kf-panel').animate({
            right: '0',
            opacity: 'show'
        }, 900);

        $('.kf-panel-content').animate({
            right: '-250',
            opacity: 'show'
        }, 800);
        var ip = ipa();
        $(document).ready(init(ip, "20009"));
    }

    btnOpen_1.addEventListener('click', function (e) {
        var img_pathc = $("#img_1")[0].src;
        $("#img_head").attr('src', img_pathc);
        open_chat_windows();
    })
    btnOpen_2.addEventListener('click', function (e) {
        var img_pathc = $("#img_2")[0].src;
        $("#img_head").attr('src', img_pathc);
        open_chat_windows();
    })
    btnOpen_3.addEventListener('click', function (e) {
        var img_pathc = $("#img_3")[0].src;
        $("#img_head").attr('src', img_pathc);
        open_chat_windows();
    })
    btnOpen_4.addEventListener('click', function (e) {
        var img_pathc = $("#img_4")[0].src;
        $("#img_head").attr('src', img_pathc);
        open_chat_windows();
    })
    btnOpen_5.addEventListener('click', function (e) {
        var img_pathc = $("#img_5")[0].src;
        $("#img_head").attr('src', img_pathc);
        open_chat_windows();
    })

    //打开留言
    btnopen_ly.addEventListener('click', function (e) {
        $('#pop_ly_id_div').show();
    })
    //关闭留言
    btnopen_ly_close.addEventListener('click', function (e) {
        $('#pop_ly_id_div').hide();
    })

    // 提交留言
    // $('#msg_sub_button').click(function(){
    //     if($("#msg_uname").val()=="" || $("#msg_uname").val()=="请输入您的称呼"){alert("请输入您的称呼!");return false;}
    //     if($("#msgtext").val()=="" || $("#msgtext").val()=="请输入留言内容"){alert("请输入留言内容!");return false;}
    //     if($("#msg_vcode").val()=="" || $("#msg_vcode").val()=="请输入验证码"){alert("请输入验证码!");return false;}
    //     $(this).html("正在提交...");
    //     $(this).attr("disabled",true);
    //     var d="toUser="+kuse+"&msg_uname="+escape($("#msg_uname").val())+"&msg_uemail="+escape($("#msg_uemail").val())+"&msg_utel="+escape($("#msg_utel").val())+"&msgtext="+escape($("#msgtext").val())+"&msg_vcode="+escape($("#msg_vcode").val())+"";
    //     if(isSync==1){d+="&msg_tomail="+escape(send_to_email);}
    //     $.ajax({
    //         type:"post",
    //         url:wzh+"/msg_book_save.asp?r="+Math.random(),
    //         dataType:"jsonp",
    //         jsonp:"callbackparam",
    //         jsonpCallback:"success_jsonpCallback",
    //         data:d,
    //         success:function(json){
    //             if(json[0].statu==1){
    //                 alert(unescape(json[0].msg));$("#msg_uname").val("请输入您的称呼");$("#msg_uemail").val("请输入您的邮箱");$("#msg_utel").val("请输入您的电话");$("#msgtext").val("请输入留言内容");$("#msg_vcode").val("请输入验证码");
    //                 $("#pop_ly_id_div").hide();
    //             }
    //             else{
    //                 alert(unescape(json[0].msg));
    //             }
    //             $('#vcode').attr('src',wzh+'/GetCode.asp?r='+Math.random());
    //             $("#msg_sub_button").attr("disabled", false);
    //             $("#msg_sub_button").html("确 定");
    //         },
    //         error:function(XMLHttpRequest, textStatus, errorThrown){
    //         }
    //     })
    // })


    //关闭对话窗体
    function close_chat_windows() {
        $('.dialogue-main').animate({'height': '0'}, function () {
            $('.dialogue-main').css({'display': 'none'});
            $('.dialogue-support-btn').css({'display': 'inline-block'});
        });
        disconnect();
    }

    btnClose.addEventListener('click', function (e) {
        close_chat_windows();
    })

    dialogueInput.addEventListener('keydown', function (e) {
        var e = e || window.event;
        if (e.keyCode == 16) {
            shiftKeyOn = true;
        }
        if (shiftKeyOn) {
            return true;
        } else if (e.keyCode == 13 && dialogueInput.value == '') {
            // console.log('发送内容不能为空');
            // 多次触发只执行最后一次渐隐
            setTimeout(function () {
                fadeIn(dialogueHint);
                clearTimeout(timerId)
                timer = setTimeout(function () {
                    fadeOut(dialogueHint)
                }, 2000);
            }, 10);
            timerId = timer;
            return true;
        } else if (e.keyCode == 13) {

            if (submitText(dialogueInput.value) == true) {


                var nodeP = doc.createElement('p'),
                    nodeSpan = doc.createElement('span');
                nodeP.classList.add('dialogue-customer-contain');
                nodeSpan.classList.add('dialogue-text', 'dialogue-customer-text');
                nodeSpan.innerHTML = dialogueInput.value;
                nodeP.appendChild(nodeSpan);
                dialogueContain.appendChild(nodeP);
                dialogueContain.scrollTop = dialogueContain.scrollHeight;
            }
        }
    });

    dialogueInput.addEventListener('keyup', function (e) {
        var e = e || window.event;
        if (e.keyCode == 16) {
            shiftKeyOn = false;
            return true;
        }
        if (!shiftKeyOn && e.keyCode == 13) {
            dialogueInput.value = null;
        }
    });


    // 渐隐
    function fadeOut(obj) {
        var n = 100;
        var time = setInterval(function () {
            if (n > 0) {
                n -= 10;
                obj.style.opacity = '0.' + n;
            } else if (n <= 30) {
                obj.style.opacity = '0';
                clearInterval(time);
            }
        }, 10);
        return true;
    }

    // 渐显
    function fadeIn(obj) {
        var n = 30;
        var time = setInterval(function () {
            if (n < 90) {
                n += 10;
                obj.style.opacity = '0.' + n;
            } else if (n >= 80) {

                obj.style.opacity = '1';
                clearInterval(time);
            }
        }, 100);
        return true;
    }

//
//
//
//    面板操作
    $('#kf-panel-open').click(function () {
        $('.kf-panel').animate({
            right: '-50'
        }, 400);
        $('.kf-panel-content').animate({
            right: '0',
            opacity: 'show'
        }, 800);
        close_chat_windows();


    });

    $('.kf-panel-close').click(function () {
        $('.kf-panel').animate({
            right: '0',
            opacity: 'show'
        }, 400);
        $('.kf-panel-content').animate({
            right: '-250',
            opacity: 'show'
        }, 800);

    });

// });
//
//
//
// 套接字操作
    window.onunload = function (event) {
        disconnect()
    }

    function init(ip, port) {
        if ("WebSocket" in window) {
            connect(ip, port);
        }
        ;

    };

    function connect(ip, port) {
        wsHost = 'ws://' + ip + ':' + port;
        websocket = new WebSocket(wsHost);
        websocket.onopen = function (evt) {
            onOpen(evt)
        };
        websocket.onclose = function (evt) {
            onClose(evt)
        };
        websocket.onmessage = function (evt) {
            onMessage(evt)
        };
        websocket.onerror = function (evt) {
            onError(evt)
        };

    };

    function Login(name) {
        websocket.send(name);

    }

// tpull_msg_unpack = record
// senderid, // 发送者id
//     toid, nick, // 发送者昵称
//     msgtype, // 个人/群组
//     content, sendtime: string;
// msgid: string;
// end;


    function protocol_handle(js_value) {
        if (js_value.protocol == 1) {
            var text = {"0x02": js_value.data[0].account};
            account_ = js_value.data[0].account;
            Login(JSON.stringify(text));

        } else if (js_value.protocol == 6) {
            //客服id
            kefu_id_ = js_value.data[0].toid;


        }

    }


//{"resultCode":0,"resultMsg":"ok","protocol":1,"data":{"account":"52482717"}}
    function onMessage(evt) {
        var js_value = JSON.parse(evt.data);
        if (js_value.resultCode == 0) {
            if (js_value.protocol == 5) {

                var string = js_value.data;
                var bb = JSON.parse(string);
                recv_data(bb.content);

            } else
                protocol_handle(js_value);

        } else {
            var errorid = js_value.resultCode;
            error_handle(errorid);
        }
    }


    function disconnect() {
        if (websocket.readyState == websocket.OPEN) {
            var d = new Date();
            var year = d.getFullYear();

            var month = d.getMonth() + 1;
            var day = d.getDate();
            var dt = year + '-' + month + '-' + day + ' ' + d.getHours() + ':' + d.getMinutes();//+':'+d.getSeconds();

            var gv = {
                "senderid": account_,
                "toid": kefu_id_,
                "nick": "",
                "msgtype": "text",
                "content": "访客" + account_ + "已离线",
                "sendtime": dt,
                "msgid": ""
            };
            var text = {"0x03_web_visitor": gv};
            websocket.send(JSON.stringify(text));

            kefu_id_ = "";
            websocket.close(1000);

        }
    }


    function clock() {
        var text = {"0x07": "heart_"};
        websocket.send(JSON.stringify(text));

    }

//发送请求账号信息
    function onOpen(evt) {
        var text = '{"0x01":"info"}';
        websocket.send(text);
        clock_int = self.setInterval("clock()", 20000);
    };

//关闭定时器
    function onClose(evt) {
        window.clearInterval(clock_int);
    };

    function onError(evt) {
        window.clearInterval(clock_int);
    };

    function submitText(text) {
        if (websocket.readyState == websocket.OPEN) {

            var d = new Date();
            var year = d.getFullYear();

            var month = d.getMonth() + 1;
            var day = d.getDate();
            var dt = year + '-' + month + '-' + day + ' ' + d.getHours() + ':' + d.getMinutes();//+':'+d.getSeconds();


            if (kefu_id_ == undefined || kefu_id_ == "") {

                var gv = {
                    "senderid": account_,
                    "toid": "",
                    "nick": "",
                    "msgtype": "text",
                    "content": text,
                    "sendtime": dt,
                    "msgid": ""
                };
                var text = {"0x03_web_visitor": gv};
                websocket.send(JSON.stringify(text));
            } else {

                var gv = {
                    "senderid": account_,
                    "toid": kefu_id_,
                    "nick": "",
                    "msgtype": "text",
                    "content": text,
                    "sendtime": dt,
                    "msgid": ""
                };
                var text = {"0x03_web_visitor": gv};
                websocket.send(JSON.stringify(text));
            }
            return true;
        } else
            return false
    }

//
//
//
//
//

});
